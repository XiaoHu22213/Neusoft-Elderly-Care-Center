const module = '/admin'
export default {
	list: module + '/list',
	del: module + '/del',
	check: module + '/check',
	add: module + '/add',
	update: module + '/update',
	getById: module + '/getById'
}